import React from 'react'

const Carrinho = () => {
  return (
    <div>Carrinho</div>
  )
}

export default Carrinho