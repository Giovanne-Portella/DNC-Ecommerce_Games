import React from 'react'

const Pay = () => {
  return (
    <div>Pay</div>
  )
}

export default Pay